#version 440 core

struct Material 
{
   vec3 ambientColor;
   float ambientStrength;
   vec3 diffuseColor;
   vec3 specularColor;
   float shininess;
}; 

struct DirectionalLight {
   vec3 direction;
   vec3 ambientColor;
   vec3 diffuse;
   vec3 specular;
   
   float focalStrength;
   float specularIntensity;
};

struct PointLight {
   vec3 position;
   bool bEnabled;

   vec3 ambient;
   vec3 diffuse;
   vec3 specular;

   // For Attenuation
   float constant;
   float linear;
   float quadratic;
};

struct LightSource 
{
   vec3 position;	
   vec3 ambientColor;
   vec3 diffuseColor;
   vec3 specularColor;
   float focalStrength;
   float specularIntensity;
};

#define TOTAL_LIGHTS 4

in vec3 fragmentPosition;
in vec3 fragmentVertexNormal;
in vec2 fragmentTextureCoordinate;
in vec4 vFragPosLightSpace;

out vec4 outFragmentColor;

uniform bool bUseTexture=false;
uniform bool bUseLighting=false;
uniform vec4 objectColor = vec4(1.0f);
uniform sampler2D objectTexture;
uniform vec3 viewPosition;
uniform vec2 UVscale = vec2(1.0f, 1.0f);

//Lighting
uniform DirectionalLight directionalLight;
uniform PointLight pointLights[TOTAL_LIGHTS];
//Light maps
uniform Material material;
uniform sampler2D shadowMap;
uniform mat4 lightSpaceMatrix;
uniform bool bisDepthPass;
const float TEXEL_SIZE = 1.0 / 1024.0;
//shader alpha
uniform float alpha = 1.0f;

//function forward declarations
float CalculateShadow(vec4 fragPosLightSpace, vec3 normal, vec3 lightDir);
vec3 CalculateDirectionalLighting();
vec3 CalculatePointLights();

void main()
{
   //if the depth pass skip the calculations for color/textures/lighting.
   if(bisDepthPass) {return;}

   //Render from lights perspective for shadow map
   vec4 fragPosLightSpace = vFragPosLightSpace;

   vec3 result = vec3(0.0);
   
   vec3 lightNormal = normalize(fragmentVertexNormal);
   vec3 finalLightColor = vec3(0.0);
   vec3 textureColor = bUseTexture ? texture(objectTexture, fragmentTextureCoordinate * UVscale).rgb : objectColor.xyz;

   if(bUseLighting == true)
   {
      //Directional Light
      {
         vec3 lightDir = normalize(-directionalLight.direction);
            
         // Calculate components
         vec3 ambient = directionalLight.ambientColor + (material.ambientColor * material.ambientStrength);
         vec3 diffuse = max(dot(lightNormal, lightDir), 0.0) * directionalLight.ambientColor * material.diffuseColor;
         vec3 viewDir = normalize(viewPosition - fragmentPosition);
         vec3 reflectDir = reflect(-lightDir, lightNormal);
         float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), directionalLight.focalStrength);
         vec3 specular = (directionalLight.specularIntensity * material.shininess) * specularComponent * material.specularColor;

         float shadowFactor = CalculateShadow(fragPosLightSpace, lightNormal, lightDir);
         vec3 directional_result = ambient + shadowFactor * (diffuse + specular);
         finalLightColor += directional_result;

      }

      //Point Lights
      {
         for(int i = 0; i < TOTAL_LIGHTS; i++){
            PointLight light = pointLights[i];
            if(!light.bEnabled) continue;

            vec3 lightDir = normalize(light.position - fragmentPosition);
            float diff = max(dot(fragmentVertexNormal, lightDir), 0.0);
            vec3 reflectDir = reflect(-lightDir, fragmentVertexNormal);
            vec3 viewDir = normalize(viewPosition - fragmentPosition);
            float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
            float dist = length(light.position - fragmentPosition);
            float attenuation = 1.0 / (light.constant + light.linear * dist + light.quadratic * (dist * dist));

            vec3 ambient = light.ambient;
            vec3 diffuse = light.diffuse * diff;
            vec3 specular = light.specular * spec;
            ambient *= attenuation;
            diffuse *= attenuation;
            specular *= attenuation;
         
            finalLightColor += (ambient + diffuse + specular);
         }
      }
   }
   else 
   {
      finalLightColor = vec3(1.0);
   }
   //Send final result out
   outFragmentColor = vec4(finalLightColor * textureColor, alpha);
}

float CalculateShadow(vec4 fragPosLightSpace, vec3 normal, vec3 lightDir){
   float shadow, bias = 0.0;
   vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
   projCoords = projCoords * 0.5 + 0.5;
   if (projCoords.x < 0.0 || projCoords.x > 1.0 || 
      projCoords.y < 0.0 || projCoords.y > 1.0 || 
      projCoords.z > 1.0)
   {
      return 1.0; 
   }
   // Prevent shadow acne
   bias = max(0.005 * (1.0 - dot(normal, lightDir)), 0.0005);

   //PCF
   shadow = 0.0;
   float currentDepth = projCoords.z;
   int samples = 0;

   for (int x = -1; x <= 1; ++x){
      for (int y = -1; y <= 1; ++y){
         vec2 offsetCoords = projCoords.xy + vec2(x, y) * TEXEL_SIZE * 1.5;

         float closestDepth = texture(shadowMap, offsetCoords).r;

         if(currentDepth > closestDepth + bias){
            shadow += 0.0;
         }
         else {
            shadow += 1.0;
         }
         samples++;
      }
   }


   return shadow / float(samples);
}