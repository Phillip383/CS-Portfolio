#version 330 core
layout (location = 0) in vec3 inVertexPosition;
layout (location = 1) in vec3 inVertexNormal;
layout (location = 2) in vec2 inTextureCoordinate;

out vec3 fragmentPosition;
out vec3 fragmentVertexNormal;
out vec2 fragmentTextureCoordinate;
out vec4 vFragPosLightSpace;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
uniform bool bisDepthPass;
uniform mat4 lightSpaceMatrix;

void main()
{
   if(bisDepthPass){
      gl_Position = lightSpaceMatrix * model * vec4(inVertexPosition, 1.0);
      vFragPosLightSpace = vec4(0.0);
   }
   else{
      fragmentPosition = vec3(model * vec4(inVertexPosition, 1.0));
      gl_Position = projection * view * model * vec4(inVertexPosition, 1.0f);
      mat3 normalMatrix = transpose(inverse(mat3(model)));
      fragmentVertexNormal = normalize(normalMatrix * inVertexNormal);
      fragmentTextureCoordinate = inTextureCoordinate;
      vFragPosLightSpace = lightSpaceMatrix * model * vec4(inVertexPosition, 1.0f);
   }
}